"""
Vigilant Spirit Dream Journal - Backend API
Real XAI classification with SHAP + LIME

Endpoints:
  POST /api/classify - Classify dream text with explanations
  GET /api/health - Health check
"""

import os
import json
import pickle
import numpy as np
from flask import Flask, request, jsonify
from flask_cors import CORS
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.multiclass import OneVsRestClassifier

# Try to import XAI libraries
try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False
    print("SHAP not available - using coefficient-based explanations")

try:
    from lime.lime_text import LimeTextExplainer
    LIME_AVAILABLE = True
except ImportError:
    LIME_AVAILABLE = False
    print("LIME not available - using coefficient-based explanations")

app = Flask(__name__)
CORS(app)

# Global model objects
model = None
vectorizer = None
feature_names = None
shap_explainers = None
lime_explainer = None

DIMENSIONS = ['Spiritual', 'Trauma', 'Maintenance']

STOPWORDS = ['dream', 'dreamed', 'dreaming', 'woke', 'wake', 'sleep', 'sleeping',
             'like', 'kind', 'really', 'stuff', 'thing', 'know', 'mean', 'sort',
             'basically', 'actually', 'just', 'going', 'went', 'said', 'told',
             'got', 'get', 'would', 'could', 'one', 'two', 'see', 'saw']

# Interpretation templates
SOURCE_INTERPRETATIONS = {
    'spiritual_dominant': {
        'title': 'Potentially Divine Communication',
        'icon': '✨',
        'guidance': "This dream's spiritual content is notably high. Apply the Discernment Checklist: Does it align with Scripture? Does it produce peace (consolation) or anxiety (desolation)? Consider sharing with trusted spiritual counsel."
    },
    'trauma_dominant': {
        'title': 'Trauma Processing / Threat Simulation',
        'icon': '⚠️',
        'guidance': "Your brain appears to be processing threat-related material. Consider using the Restoration phase (IRT) to rewrite this dream with a safe ending. Remember: the dream cannot hurt you. You are safe now."
    },
    'maintenance_dominant': {
        'title': 'Biological Processing',
        'icon': '🧠',
        'guidance': "This appears to be a standard 'maintenance' dream where your brain is filing away recent experiences. No special action required. Note any psychological insights."
    },
    'mixed_spiritual_trauma': {
        'title': 'Spiritual Warfare / Shadow Work',
        'icon': '⚔️',
        'guidance': "This dream combines spiritual and distressing elements. This may represent spiritual warfare or areas requiring healing. Pray for protection and wisdom."
    },
    'mixed_all': {
        'title': 'Complex Multi-Dimensional Dream',
        'icon': '🔮',
        'guidance': "This dream contains elements across multiple dimensions. Apply careful discernment: separate divine signal from biological noise."
    }
}

DIMENSION_INTERPRETATIONS = {
    'Spiritual': {
        'high': "This dream contains strong spiritual content suggesting potential divine communication.",
        'medium': "Some spiritual elements present, interwoven with other themes.",
        'low': "No significant spiritual content detected."
    },
    'Trauma': {
        'high': "Significant trauma-related content detected. Consider IRT approach if recurring.",
        'medium': "Some distressing elements present, possibly normal stress processing.",
        'low': "No significant trauma-related content."
    },
    'Maintenance': {
        'high': "Primarily maintenance processing - brain consolidating everyday experiences.",
        'medium': "Ordinary life elements mixed with other themes.",
        'low': "Dream moves beyond ordinary processing into more symbolic territory."
    }
}


def initialize_model():
    """Initialize or train the model"""
    global model, vectorizer, feature_names, shap_explainers, lime_explainer
    
    model_path = os.path.join(os.path.dirname(__file__), 'dream_classifier_model.pkl')
    
    if os.path.exists(model_path):
        print(f"Loading model from {model_path}")
        with open(model_path, 'rb') as f:
            data = pickle.load(f)
        model = data['model']
        vectorizer = data['vectorizer']
        feature_names = data['feature_names']
        X_background = data.get('X_background')
        
        # Initialize SHAP explainers
        if SHAP_AVAILABLE and X_background is not None:
            shap_explainers = []
            for estimator in model.estimators_:
                exp = shap.LinearExplainer(estimator, X_background)
                shap_explainers.append(exp)
            print("SHAP explainers initialized")
        
        # Initialize LIME explainer
        if LIME_AVAILABLE:
            lime_explainer = LimeTextExplainer(
                class_names=DIMENSIONS,
                split_expression=r'\W+',
                random_state=42
            )
            print("LIME explainer initialized")
            
        print(f"Model loaded: {len(feature_names)} features")
    else:
        print("No saved model found - training new model...")
        train_new_model()


def train_new_model():
    """Train a new model from sample data"""
    global model, vectorizer, feature_names, shap_explainers, lime_explainer
    
    # Sample training data (minimal for demo)
    sample_dreams = [
        # Spiritual
        ("I saw Jesus in heaven surrounded by angels singing praise to God", [1, 0, 0]),
        ("God spoke to me in a vision about my future calling", [1, 0, 0]),
        ("I was praying in church when divine light filled the room", [1, 0, 0]),
        ("Angels appeared and told me not to be afraid", [1, 0, 0]),
        ("I saw the throne of God with worship all around", [1, 0, 0]),
        # Trauma
        ("I was being chased by someone trying to kill me", [0, 1, 0]),
        ("There was a terrible accident with blood everywhere", [0, 1, 0]),
        ("I was trapped and couldn't escape the fire", [0, 1, 0]),
        ("Someone attacked me and I was helpless", [0, 1, 0]),
        ("I was in a war zone with bombs exploding", [0, 1, 0]),
        # Maintenance
        ("I drove to work and had a meeting with my boss", [0, 0, 1]),
        ("I was at school taking an exam I forgot about", [0, 0, 1]),
        ("I went shopping at the grocery store with my family", [0, 0, 1]),
        ("I was cooking dinner at home with friends", [0, 0, 1]),
        ("I walked through my old neighborhood", [0, 0, 1]),
        # Mixed
        ("Jesus appeared during a nightmare to save me from demons", [1, 1, 0]),
        ("I was praying at church then drove home to cook dinner", [1, 0, 1]),
        ("I had a terrifying vision of the apocalypse", [1, 1, 0]),
    ]
    
    texts = [d[0] for d in sample_dreams]
    labels = np.array([d[1] for d in sample_dreams])
    
    vectorizer = TfidfVectorizer(
        max_features=500,
        ngram_range=(1, 2),
        stop_words=STOPWORDS,
        min_df=1
    )
    
    X = vectorizer.fit_transform(texts)
    feature_names = vectorizer.get_feature_names_out()
    
    model = OneVsRestClassifier(
        LogisticRegression(max_iter=1000, C=0.5, class_weight='balanced', random_state=42)
    )
    model.fit(X, labels)
    
    # Initialize explainers
    if SHAP_AVAILABLE:
        shap_explainers = []
        for estimator in model.estimators_:
            exp = shap.LinearExplainer(estimator, X)
            shap_explainers.append(exp)
    
    if LIME_AVAILABLE:
        lime_explainer = LimeTextExplainer(
            class_names=DIMENSIONS,
            split_expression=r'\W+',
            random_state=42
        )
    
    print(f"Model trained on {len(texts)} samples with {len(feature_names)} features")


def predict_proba_for_lime(texts):
    """Prediction function for LIME"""
    X = vectorizer.transform(texts)
    return model.predict_proba(X)


def get_coefficient_features(dim_idx, top_k=6):
    """Get top features from model coefficients"""
    coef = model.estimators_[dim_idx].coef_[0]
    top_indices = np.argsort(np.abs(coef))[-top_k:][::-1]
    
    features = []
    for idx in top_indices:
        if abs(coef[idx]) > 0.01:
            features.append({
                'word': feature_names[idx],
                'weight': float(coef[idx]),
                'direction': 'supports' if coef[idx] > 0 else 'opposes'
            })
    return features


def get_shap_features(X, dim_idx, top_k=6):
    """Get SHAP feature attributions"""
    if not SHAP_AVAILABLE or shap_explainers is None:
        return get_coefficient_features(dim_idx, top_k)
    
    shap_values = shap_explainers[dim_idx].shap_values(X)[0]
    
    features = []
    for j, val in enumerate(shap_values):
        if abs(val) > 0.01:
            features.append({
                'word': feature_names[j],
                'weight': float(val),
                'direction': 'supports' if val > 0 else 'opposes'
            })
    
    features.sort(key=lambda x: abs(x['weight']), reverse=True)
    return features[:top_k]


def get_lime_features(text, dim_idx, num_features=6):
    """Get LIME feature attributions"""
    if not LIME_AVAILABLE or lime_explainer is None:
        return get_coefficient_features(dim_idx, num_features)
    
    try:
        exp = lime_explainer.explain_instance(
            text,
            predict_proba_for_lime,
            num_features=num_features,
            labels=[dim_idx]
        )
        
        features = []
        for word, weight in exp.as_list(label=dim_idx):
            features.append({
                'word': word,
                'weight': float(weight),
                'direction': 'supports' if weight > 0 else 'opposes'
            })
        return features
    except Exception as e:
        print(f"LIME error: {e}")
        return get_coefficient_features(dim_idx, num_features)


def calculate_agreement(shap_feats, lime_feats):
    """Calculate agreement between SHAP and LIME"""
    if not shap_feats or not lime_feats:
        return 0.0
    
    shap_words = {f['word']: f['weight'] > 0 for f in shap_feats}
    lime_words = {f['word']: f['weight'] > 0 for f in lime_feats}
    
    common = set(shap_words.keys()) & set(lime_words.keys())
    if not common:
        return 0.0
    
    agreements = sum(1 for w in common if shap_words[w] == lime_words[w])
    return agreements / len(common)


def determine_source_type(probabilities):
    """Determine the overall source classification"""
    threshold = 0.5
    above = [dim for dim, prob in probabilities.items() if prob > threshold]
    
    if len(above) == 0:
        return 'maintenance_dominant'
    elif len(above) == 1:
        return f'{above[0].lower()}_dominant'
    elif 'Spiritual' in above and 'Trauma' in above:
        return 'mixed_spiritual_trauma'
    else:
        return 'mixed_all'


def generate_interpretation(probabilities, shap_explanations, source_type):
    """Generate natural language interpretation"""
    spiritual = probabilities['Spiritual']
    trauma = probabilities['Trauma']
    maintenance = probabilities['Maintenance']
    
    if spiritual > 0.6 and trauma > 0.5:
        shap_sp = [f['word'] for f in shap_explanations['Spiritual'][:3]]
        shap_tr = [f['word'] for f in shap_explanations['Trauma'][:3]]
        return f"This dream combines divine imagery ({spiritual*100:.0f}%) with distressing elements ({trauma*100:.0f}%). Key spiritual markers: {', '.join(shap_sp)}. Trauma markers: {', '.join(shap_tr)}. This pattern often appears in spiritual warfare dreams or when God is addressing areas requiring healing."
    
    elif spiritual > 0.6:
        shap_sp = [f['word'] for f in shap_explanations['Spiritual'][:4]]
        return f"This dream registers as primarily spiritual ({spiritual*100:.0f}%). Key indicators: {', '.join(shap_sp)}. Apply the Discernment Checklist and consider how God may be speaking to your incubation request."
    
    elif trauma > 0.6:
        shap_tr = [f['word'] for f in shap_explanations['Trauma'][:4]]
        return f"This dream registers as trauma/threat processing ({trauma*100:.0f}%). Key indicators: {', '.join(shap_tr)}. Your brain is running a threat simulation. The IRT approach is designed for this: identify Core Threat, write Mastery Action, rehearse Safe Ending."
    
    elif maintenance > 0.5:
        shap_mt = [f['word'] for f in shap_explanations['Maintenance'][:3]]
        return f"This dream registers as maintenance processing ({maintenance*100:.0f}%). Elements like {', '.join(shap_mt)} suggest your brain is consolidating recent memories. This is healthy cognitive function."
    
    else:
        return "This dream shows mixed or subtle patterns without a dominant dimension. Continue with the full journaling workflow and pay attention to emotional fruit and repetition."


@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'model_loaded': model is not None,
        'shap_available': SHAP_AVAILABLE and shap_explainers is not None,
        'lime_available': LIME_AVAILABLE and lime_explainer is not None,
        'features': len(feature_names) if feature_names is not None else 0
    })


@app.route('/api/classify', methods=['POST'])
def classify():
    """
    Classify dream text with XAI explanations
    
    Request:
        { "text": "dream narrative and other fields combined" }
    
    Response:
        {
            "success": true,
            "probabilities": { "Spiritual": 0.85, ... },
            "shap": { "Spiritual": [...], ... },
            "lime": { "Spiritual": [...], ... },
            "agreement": { "Spiritual": 0.8, ... },
            "sourceType": "spiritual_dominant",
            "sourceInfo": { "title": "...", "guidance": "..." },
            "interpretation": "Natural language interpretation...",
            "wordCount": 45
        }
    """
    try:
        data = request.get_json()
        
        if not data or 'text' not in data:
            return jsonify({'success': False, 'error': 'Missing text field'}), 400
        
        text = data['text']
        words = text.lower().split()
        
        # Get predictions
        X = vectorizer.transform([text])
        probs = model.predict_proba(X)[0]
        probabilities = {dim: float(probs[i]) for i, dim in enumerate(DIMENSIONS)}
        
        # Get explanations
        shap_explanations = {}
        lime_explanations = {}
        agreement = {}
        
        for i, dim in enumerate(DIMENSIONS):
            shap_explanations[dim] = get_shap_features(X, i, top_k=6)
            lime_explanations[dim] = get_lime_features(text, i, num_features=6)
            agreement[dim] = calculate_agreement(shap_explanations[dim], lime_explanations[dim])
        
        # Determine source type and get interpretation
        source_type = determine_source_type(probabilities)
        source_info = SOURCE_INTERPRETATIONS.get(source_type, SOURCE_INTERPRETATIONS['mixed_all'])
        interpretation = generate_interpretation(probabilities, shap_explanations, source_type)
        
        return jsonify({
            'success': True,
            'probabilities': probabilities,
            'shap': shap_explanations,
            'lime': lime_explanations,
            'agreement': agreement,
            'sourceType': source_type,
            'sourceInfo': source_info,
            'interpretation': interpretation,
            'wordCount': len(words),
            'dimensionInterpretations': {
                dim: DIMENSION_INTERPRETATIONS[dim]['high' if probabilities[dim] > 0.7 else 'medium' if probabilities[dim] > 0.4 else 'low']
                for dim in DIMENSIONS
            }
        })
        
    except Exception as e:
        print(f"Classification error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


if __name__ == '__main__':
    initialize_model()
    port = int(os.environ.get('PORT', 5000))
    print(f"Starting API server on port {port}")
    app.run(host='0.0.0.0', port=port, debug=False)
